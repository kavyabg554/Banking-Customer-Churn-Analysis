import os
import sys
from flask import Flask, render_template, jsonify, request, Response

# Add current dir to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import config
from data.generate_dataset import generate_banking_data, build_database
from modules.db_engine import DatabaseEngine
from modules.data_cleaner import DataCleanerEngine
from modules.analytics_engine import AnalyticsEngine
from modules.ml_scoring import MachineLearningScoringEngine
from modules.report_generator import ReportGeneratorEngine

app = Flask(__name__)
app.config['SECRET_KEY'] = config.SECRET_KEY

# Ensure Database Exists on startup
if not os.path.exists(config.DB_PATH):
    print("Database not found. Initializing database and generating 10,000 records...")
    build_database()

# Initialize Engine Instances
db = DatabaseEngine()

def get_current_df():
    """Fetches full customer dataframe from database."""
    return db.fetch_dataframe("SELECT * FROM customers")

# Pre-train ML model on app start
df_initial = get_current_df()
cleaner = DataCleanerEngine(df_initial)
cleaned_data = cleaner.clean_pipeline()
analytics = AnalyticsEngine(cleaned_data['cleaned_df'])
ml_engine = MachineLearningScoringEngine(cleaned_data['cleaned_df'])
ml_engine.train_model()
report_engine = ReportGeneratorEngine(analytics)

@app.route('/')
def index():
    """Renders the main Banking Analytics Dashboard SPA."""
    return render_template('index.html')

@app.route('/api/kpis', methods=['GET'])
def api_kpis():
    """Returns Executive KPIs."""
    df = get_current_df()
    an = AnalyticsEngine(df)
    return jsonify(an.get_executive_kpis())

@app.route('/api/charts/geography', methods=['GET'])
def api_chart_geography():
    df = get_current_df()
    an = AnalyticsEngine(df)
    return jsonify(an.get_geography_analytics())

@app.route('/api/charts/age', methods=['GET'])
def api_chart_age():
    df = get_current_df()
    an = AnalyticsEngine(df)
    return jsonify(an.get_age_bracket_analytics())

@app.route('/api/charts/products', methods=['GET'])
def api_chart_products():
    df = get_current_df()
    an = AnalyticsEngine(df)
    return jsonify(an.get_product_analytics())

@app.route('/api/charts/segments', methods=['GET'])
def api_chart_segments():
    df = get_current_df()
    an = AnalyticsEngine(df)
    return jsonify(an.get_segment_analytics())

@app.route('/api/statistics', methods=['GET'])
def api_statistics():
    df = get_current_df()
    an = AnalyticsEngine(df)
    tests = an.run_statistical_hypothesis_tests()
    corr = an.get_correlation_matrix()
    return jsonify({
        'tests': tests,
        'correlation': corr
    })

@app.route('/api/insights', methods=['GET'])
def api_insights():
    df = get_current_df()
    an = AnalyticsEngine(df)
    rep = ReportGeneratorEngine(an)
    return jsonify(rep.generate_executive_insights())

@app.route('/api/ml/metrics', methods=['GET'])
def api_ml_metrics():
    return jsonify({
        'metrics': ml_engine.metrics,
        'feature_importances': ml_engine.feature_importances
    })

@app.route('/api/ml/predict', methods=['POST'])
def api_ml_predict():
    payload = request.get_json() or {}
    result = ml_engine.predict_single_customer_risk(payload)
    return jsonify(result)

@app.route('/api/sql/execute', methods=['POST'])
def api_sql_execute():
    payload = request.get_json() or {}
    query = payload.get('query', '')
    result = db.execute_custom_sql(query)
    return jsonify(result)

@app.route('/api/sql/templates', methods=['GET'])
def api_sql_templates():
    return jsonify(db.get_sample_queries())

@app.route('/api/customers', methods=['GET'])
def api_customers():
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 15))
    search = request.args.get('search', '').strip()
    geography = request.args.get('geography', 'All')
    risk_tier = request.args.get('risk_tier', 'All')
    
    query = "SELECT * FROM customers WHERE 1=1"
    params = []
    
    if search:
        query += " AND (surname LIKE ? OR CAST(customer_id AS TEXT) LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
        
    if geography != 'All':
        query += " AND geography = ?"
        params.append(geography)
        
    if risk_tier == 'High':
        query += " AND risk_score >= 0.65"
    elif risk_tier == 'Medium':
        query += " AND risk_score >= 0.35 AND risk_score < 0.65"
    elif risk_tier == 'Low':
        query += " AND risk_score < 0.35"
        
    query += " ORDER BY risk_score DESC"
    
    count_query = f"SELECT COUNT(*) FROM ({query})"
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute(count_query, params)
    total_records = cursor.fetchone()[0]
    
    offset = (page - 1) * per_page
    query += f" LIMIT {per_page} OFFSET {offset}"
    
    df_res = db.fetch_dataframe(query, params)
    
    return jsonify({
        'total_records': total_records,
        'page': page,
        'per_page': per_page,
        'total_pages': (total_records + per_page - 1) // per_page,
        'customers': df_res.to_dict(orient='records')
    })

@app.route('/api/customers/<int:customer_id>', methods=['GET'])
def api_customer_detail(customer_id):
    df_res = db.fetch_dataframe("SELECT * FROM customers WHERE customer_id = ?", params=[customer_id])
    if df_res.empty:
        return jsonify({'error': 'Customer not found'}), 404
        
    cust = df_res.iloc[0].to_dict()
    risk_info = ml_engine.predict_single_customer_risk(cust)
    cust['risk_analysis'] = risk_info
    return jsonify(cust)

@app.route('/api/etl/status', methods=['GET'])
def api_etl_status():
    return jsonify(cleaned_data['log'])

@app.route('/api/export/report', methods=['GET'])
def api_export_report():
    df = get_current_df()
    an = AnalyticsEngine(df)
    rep = ReportGeneratorEngine(an)
    md_text = rep.generate_markdown_report()
    return Response(md_text, mimetype='text/markdown', headers={'Content-Disposition': 'attachment;filename=churn_analytics_report.md'})

@app.route('/api/export/powerbi', methods=['GET'])
def api_export_powerbi():
    df = get_current_df()
    an = AnalyticsEngine(df)
    rep = ReportGeneratorEngine(an)
    pbi_json = rep.generate_powerbi_dataset_json()
    return Response(pbi_json, mimetype='application/json', headers={'Content-Disposition': 'attachment;filename=powerbi_dataset_config.json'})

if __name__ == '__main__':
    print(f"Starting Banking Customer Churn Analytics Server on http://localhost:{config.PORT}")
    app.run(host='0.0.0.0', port=config.PORT, debug=config.DEBUG)
