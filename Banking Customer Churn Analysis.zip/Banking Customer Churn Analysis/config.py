import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
DB_PATH = os.path.join(DATA_DIR, 'banking_churn.db')
SCHEMA_PATH = os.path.join(DATA_DIR, 'schema.sql')

# App Configuration
SECRET_KEY = os.environ.get('SECRET_KEY', 'banking_churn_analytics_secret_2026')
DEBUG = True
PORT = 5000

# Banking Analytics & Risk Thresholds
HIGH_RISK_THRESHOLD = 0.65       # Risk score >= 65% classified as High Risk
MEDIUM_RISK_THRESHOLD = 0.35     # Risk score between 35% and 65% classified as Medium Risk
HIGH_VALUE_BALANCE_THRESHOLD = 100000.0  # Balance >= $100,000 considered High Value Account

# Default ML Parameters
RANDOM_STATE = 42
TEST_SIZE = 0.20
N_ESTIMATORS = 100

# Geography List
GEOGRAPHIES = ['France', 'Germany', 'Spain']
GENDERS = ['Female', 'Male']
ACCOUNT_TYPES = ['Savings', 'Checking', 'Investment', 'Private Banking']
CUSTOMER_SEGMENTS = [
    'VIP High Net Worth',
    'Retiring Wealthy',
    'Young Professional',
    'Mid-Market Standard',
    'At-Risk Dormant'
]
