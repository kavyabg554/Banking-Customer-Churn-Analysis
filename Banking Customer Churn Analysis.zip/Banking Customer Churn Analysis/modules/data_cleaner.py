import pandas as pd
import numpy as np

class DataCleanerEngine:
    """Automated ETL & Data Cleaning Pipeline for Banking Datasets."""

    def __init__(self, df):
        self.df = df.copy()
        self.log = []

    def clean_pipeline(self):
        """Executes full automated data cleaning and quality audit pipeline."""
        initial_count = len(self.df)
        self.log.append(f"Started pipeline with {initial_count} records.")

        # 1. Missing Value Check & Imputation
        missing_summary = self.df.isnull().sum().to_dict()
        missing_cols = {k: v for k, v in missing_summary.items() if v > 0}
        
        if missing_cols:
            self.log.append(f"Found missing values in: {missing_cols}")
            # Impute numerical missing with median, categorical with mode
            for col in missing_cols:
                if self.df[col].dtype in ['int64', 'float64']:
                    median_val = self.df[col].median()
                    self.df[col].fillna(median_val, inplace=True)
                else:
                    mode_val = self.df[col].mode()[0]
                    self.df[col].fillna(mode_val, inplace=True)
        else:
            self.log.append("No missing values detected. Data integrity: 100%.")

        # 2. Duplicate Check
        dup_count = self.df.duplicated(subset=['customer_id']).sum()
        if dup_count > 0:
            self.df.drop_duplicates(subset=['customer_id'], keep='first', inplace=True)
            self.log.append(f"Removed {dup_count} duplicate customer records.")
        else:
            self.log.append("No duplicate records found.")

        # 3. Outlier Detection using IQR Method
        outlier_counts = self.detect_outliers_iqr(['age', 'balance', 'credit_score', 'estimated_salary'])
        self.log.append(f"Outlier scan (IQR): {outlier_counts}")

        # 4. Feature Engineering
        self.df['balance_salary_ratio'] = np.where(
            self.df['estimated_salary'] > 0,
            round(self.df['balance'] / self.df['estimated_salary'], 4),
            0.0
        )
        self.df['is_high_balance'] = (self.df['balance'] >= 100000.0).astype(int)
        self.df['is_senior'] = (self.df['age'] >= 50).astype(int)
        self.df['is_multi_product_risk'] = (self.df['num_of_products'] >= 3).astype(int)
        
        self.log.append("Created engineered features: balance_salary_ratio, is_high_balance, is_senior, is_multi_product_risk.")

        return {
            'cleaned_df': self.df,
            'log': self.log,
            'row_count': len(self.df),
            'missing_summary': missing_summary,
            'outlier_summary': outlier_counts
        }

    def detect_outliers_iqr(self, num_cols):
        """Calculates IQR upper/lower bounds and counts outliers per numeric column."""
        outliers = {}
        for col in num_cols:
            if col in self.df.columns:
                q1 = self.df[col].quantile(0.25)
                q3 = self.df[col].quantile(0.75)
                iqr = q3 - q1
                lower_bound = q1 - 1.5 * iqr
                upper_bound = q3 + 1.5 * iqr
                count = int(((self.df[col] < lower_bound) | (self.df[col] > upper_bound)).sum())
                outliers[col] = {
                    'count': count,
                    'lower_bound': round(float(lower_bound), 2),
                    'upper_bound': round(float(upper_bound), 2)
                }
        return outliers
