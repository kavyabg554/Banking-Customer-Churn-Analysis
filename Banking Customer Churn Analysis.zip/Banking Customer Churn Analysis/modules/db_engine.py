import sqlite3
import pandas as pd
import os
import sys
import time

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

class DatabaseEngine:
    """SQLite Database helper for executing queries, fetching analytics, and running custom SQL."""

    def __init__(self, db_path=None):
        self.db_path = db_path or config.DB_PATH

    def get_connection(self):
        """Returns SQLite connection with dict factory for easy JSON rendering."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def fetch_dataframe(self, query, params=None):
        """Executes SQL query and returns a pandas DataFrame."""
        conn = sqlite3.connect(self.db_path)
        try:
            df = pd.read_sql_query(query, conn, params=params)
            return df
        finally:
            conn.close()

    def execute_custom_sql(self, sql_query):
        """
        Safely executes user custom SQL queries and returns column names, rows, execution time, and row count.
        """
        start_time = time.time()
        
        # Basic SQL injection / DDL safety filter for live playground demo
        sanitized = sql_query.strip().upper()
        if any(keyword in sanitized for keyword in ['DROP TABLE', 'DELETE FROM', 'TRUNCATE', 'ALTER TABLE', 'ATTACH', 'DETACH']):
            return {
                'success': False,
                'error': 'Forbidden SQL command detected. Only SELECT, WITH, and analytical queries are allowed in this interface.'
            }

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute(sql_query)
            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            rows = cursor.fetchall()
            
            # Convert row tuples to list of lists, handling dates/nulls
            data = []
            for row in rows[:1000]:  # Limit to 1000 rows for web performance
                data.append([float(val) if isinstance(val, (int, float)) and not isinstance(val, bool) else (str(val) if val is not None else '') for val in row])
                
            execution_time = round((time.time() - start_time) * 1000, 2)
            
            return {
                'success': True,
                'columns': columns,
                'rows': data,
                'row_count': len(rows),
                'execution_time_ms': execution_time
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
        finally:
            conn.close()

    def get_sample_queries(self):
        """Pre-packaged SQL business analytics queries for interview & demonstration."""
        return [
            {
                'id': 1,
                'title': 'High-Value At-Risk Customers (Balance > $100k & Inactive)',
                'query': """SELECT 
    customer_id, surname, geography, gender, age, balance, credit_score, risk_score
FROM customers
WHERE balance >= 100000 AND is_active_member = 0 AND exited = 0
ORDER BY balance DESC
LIMIT 15;"""
            },
            {
                'id': 2,
                'title': 'Geography & Gender Churn Breakdown',
                'query': """SELECT 
    geography,
    gender,
    COUNT(*) AS total_customers,
    SUM(exited) AS churned_count,
    ROUND(AVG(exited) * 100.0, 2) AS churn_rate_pct,
    ROUND(AVG(balance), 2) AS avg_balance
FROM customers
GROUP BY geography, gender
ORDER BY churn_rate_pct DESC;"""
            },
            {
                'id': 3,
                'title': 'Multi-Product Churn Paradox Analysis',
                'query': """SELECT 
    num_of_products,
    COUNT(*) AS total_customers,
    SUM(exited) AS churned_customers,
    ROUND(AVG(exited) * 100.0, 2) AS churn_rate_pct,
    ROUND(AVG(balance), 2) AS avg_balance
FROM customers
GROUP BY num_of_products
ORDER BY num_of_products ASC;"""
            },
            {
                'id': 4,
                'title': 'Customer Lifetime Salary Quintile vs Churn',
                'query': """SELECT 
    NTILE(5) OVER (ORDER BY estimated_salary) AS salary_quintile,
    COUNT(*) AS total_customers,
    ROUND(AVG(estimated_salary), 2) AS avg_salary,
    ROUND(AVG(exited) * 100.0, 2) AS churn_rate_pct,
    ROUND(AVG(balance), 2) AS avg_balance
FROM customers
GROUP BY salary_quintile
ORDER BY salary_quintile ASC;"""
            },
            {
                'id': 5,
                'title': 'Branch Performance & Risk Exposure Summary',
                'query': """SELECT 
    branch_code,
    COUNT(*) AS customer_count,
    ROUND(AVG(credit_score), 1) AS avg_credit_score,
    ROUND(SUM(balance), 2) AS total_deposits,
    ROUND(SUM(CASE WHEN exited = 1 THEN balance ELSE 0 END), 2) AS capital_exited,
    ROUND(AVG(exited) * 100.0, 2) AS branch_churn_rate_pct
FROM customers
GROUP BY branch_code
ORDER BY total_deposits DESC;"""
            }
        ]
