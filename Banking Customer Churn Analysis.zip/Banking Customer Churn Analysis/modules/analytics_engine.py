import pandas as pd
import numpy as np
from scipy import stats

class AnalyticsEngine:
    """Core Pandas & Statistical Engine for Banking Customer Churn Analytics."""

    def __init__(self, df):
        self.df = df.copy()

    def get_executive_kpis(self):
        """Computes executive-level KPIs for high-level dashboard cards."""
        total_customers = len(self.df)
        churned_customers = int(self.df['exited'].sum())
        churn_rate = round((churned_customers / total_customers) * 100.0, 2) if total_customers > 0 else 0.0
        
        total_balance = float(self.df['balance'].sum())
        capital_at_risk = float(self.df[self.df['exited'] == 1]['balance'].sum())
        retained_capital = total_balance - capital_at_risk
        
        high_risk_customers = int((self.df['risk_score'] >= 0.65).sum())
        
        avg_credit_score = round(float(self.df['credit_score'].mean()), 1)
        avg_age = round(float(self.df['age'].mean()), 1)
        avg_salary = round(float(self.df['estimated_salary'].mean()), 2)
        active_members_pct = round(float((self.df['is_active_member'].sum() / total_customers) * 100.0), 1)

        return {
            'total_customers': total_customers,
            'churned_customers': churned_customers,
            'churn_rate_pct': churn_rate,
            'total_balance_usd': round(total_balance, 2),
            'capital_at_risk_usd': round(capital_at_risk, 2),
            'retained_capital_usd': round(retained_capital, 2),
            'high_risk_customers_count': high_risk_customers,
            'avg_credit_score': avg_credit_score,
            'avg_age': avg_age,
            'avg_salary_usd': avg_salary,
            'active_members_pct': active_members_pct
        }

    def get_geography_analytics(self):
        """Aggregates churn and balance metrics by geography."""
        geo = self.df.groupby('geography').agg(
            total_customers=('customer_id', 'count'),
            churned=('exited', 'sum'),
            avg_balance=('balance', 'mean'),
            total_balance=('balance', 'sum'),
            avg_age=('age', 'mean'),
            avg_credit_score=('credit_score', 'mean')
        ).reset_index()

        geo['churn_rate_pct'] = round((geo['churned'] / geo['total_customers']) * 100.0, 2)
        geo['avg_balance'] = round(geo['avg_balance'], 2)
        geo['total_balance'] = round(geo['total_balance'], 2)
        geo['avg_age'] = round(geo['avg_age'], 1)
        geo['avg_credit_score'] = round(geo['avg_credit_score'], 1)

        return geo.to_dict(orient='records')

    def get_age_bracket_analytics(self):
        """Aggregates churn by age cohorts (<30, 30-40, 40-50, 50-60, 60+)."""
        bins = [17, 30, 40, 50, 60, 100]
        labels = ['<30', '30-40', '40-50', '50-60', '60+']
        
        self.df['age_group'] = pd.cut(self.df['age'], bins=bins, labels=labels)
        
        age_agg = self.df.groupby('age_group', observed=False).agg(
            total_customers=('customer_id', 'count'),
            churned=('exited', 'sum'),
            avg_balance=('balance', 'mean'),
            avg_risk=('risk_score', 'mean')
        ).reset_index()

        age_agg['churn_rate_pct'] = round((age_agg['churned'] / age_agg['total_customers']) * 100.0, 2)
        age_agg['avg_balance'] = round(age_agg['avg_balance'], 2)
        age_agg['avg_risk'] = round(age_agg['avg_risk'], 4)

        return age_agg.to_dict(orient='records')

    def get_product_analytics(self):
        """Aggregates churn by number of products held."""
        prod = self.df.groupby('num_of_products').agg(
            total_customers=('customer_id', 'count'),
            churned=('exited', 'sum'),
            avg_balance=('balance', 'mean')
        ).reset_index()

        prod['churn_rate_pct'] = round((prod['churned'] / prod['total_customers']) * 100.0, 2)
        prod['avg_balance'] = round(prod['avg_balance'], 2)

        return prod.to_dict(orient='records')

    def get_segment_analytics(self):
        """Aggregates churn by customer segment."""
        seg = self.df.groupby('customer_segment').agg(
            total_customers=('customer_id', 'count'),
            churned=('exited', 'sum'),
            total_balance=('balance', 'sum'),
            avg_salary=('estimated_salary', 'mean')
        ).reset_index()

        seg['churn_rate_pct'] = round((seg['churned'] / seg['total_customers']) * 100.0, 2)
        seg['total_balance'] = round(seg['total_balance'], 2)
        seg['avg_salary'] = round(seg['avg_salary'], 2)

        return seg.to_dict(orient='records')

    def run_statistical_hypothesis_tests(self):
        """
        Executes Chi-Square tests of independence and Two-Sample T-tests 
        to statistically prove significant drivers of churn.
        """
        results = {}

        # 1. Chi-Square Test: Geography vs Exited
        contingency_geo = pd.crosstab(self.df['geography'], self.df['exited'])
        chi2_geo, p_geo, dof_geo, _ = stats.chi2_contingency(contingency_geo)
        results['geography_chi2'] = {
            'feature': 'Geography',
            'chi2_stat': round(float(chi2_geo), 3),
            'p_value': float(p_geo),
            'dof': dof_geo,
            'is_statistically_significant': bool(p_geo < 0.05),
            'conclusion': 'Geography significantly impacts churn rate (Germany has ~2x higher churn).' if p_geo < 0.05 else 'No significant difference.'
        }

        # 2. Chi-Square Test: IsActiveMember vs Exited
        contingency_active = pd.crosstab(self.df['is_active_member'], self.df['exited'])
        chi2_act, p_act, dof_act, _ = stats.chi2_contingency(contingency_active)
        results['is_active_member_chi2'] = {
            'feature': 'Active Membership',
            'chi2_stat': round(float(chi2_act), 3),
            'p_value': float(p_act),
            'dof': dof_act,
            'is_statistically_significant': bool(p_act < 0.05),
            'conclusion': 'Inactive members churn at a significantly higher rate than active members.' if p_act < 0.05 else 'No significant difference.'
        }

        # 3. Chi-Square Test: NumOfProducts vs Exited
        contingency_prod = pd.crosstab(self.df['num_of_products'], self.df['exited'])
        chi2_prod, p_prod, dof_prod, _ = stats.chi2_contingency(contingency_prod)
        results['num_of_products_chi2'] = {
            'feature': 'Number of Products',
            'chi2_stat': round(float(chi2_prod), 3),
            'p_value': float(p_prod),
            'dof': dof_prod,
            'is_statistically_significant': bool(p_prod < 0.05),
            'conclusion': 'Customers with 3+ products experience extreme churn risk (>80%).' if p_prod < 0.05 else 'No significant difference.'
        }

        # 4. Independent Two-Sample T-Test: Age (Exited vs Retained)
        age_exited = self.df[self.df['exited'] == 1]['age']
        age_retained = self.df[self.df['exited'] == 0]['age']
        t_stat_age, p_val_age = stats.ttest_ind(age_exited, age_retained, equal_var=False)
        results['age_ttest'] = {
            'feature': 'Age Difference',
            'mean_exited': round(float(age_exited.mean()), 2),
            'mean_retained': round(float(age_retained.mean()), 2),
            't_statistic': round(float(t_stat_age), 3),
            'p_value': float(p_val_age),
            'is_statistically_significant': bool(p_val_age < 0.05),
            'conclusion': f"Exited customers are significantly older (avg {round(age_exited.mean(), 1)} yrs vs {round(age_retained.mean(), 1)} yrs)."
        }

        # 5. Independent Two-Sample T-Test: Balance (Exited vs Retained)
        bal_exited = self.df[self.df['exited'] == 1]['balance']
        bal_retained = self.df[self.df['exited'] == 0]['balance']
        t_stat_bal, p_val_bal = stats.ttest_ind(bal_exited, bal_retained, equal_var=False)
        results['balance_ttest'] = {
            'feature': 'Balance Difference',
            'mean_exited': round(float(bal_exited.mean()), 2),
            'mean_retained': round(float(bal_retained.mean()), 2),
            't_statistic': round(float(t_stat_bal), 3),
            'p_value': float(p_val_bal),
            'is_statistically_significant': bool(p_val_bal < 0.05),
            'conclusion': f"Exited customers hold higher average balances (${round(bal_exited.mean(), 2)} vs ${round(bal_retained.mean(), 2)})."
        }

        return results

    def get_correlation_matrix(self):
        """Computes Pearson correlation matrix for numerical features."""
        num_cols = ['credit_score', 'age', 'tenure', 'balance', 'num_of_products', 'has_cr_card', 'is_active_member', 'estimated_salary', 'exited', 'risk_score']
        corr = self.df[num_cols].corr().round(3)
        return {
            'columns': num_cols,
            'matrix': corr.values.tolist()
        }
