/**
 * APEX FINANCIAL - EXECUTIVE DASHBOARD & ML CHARTS
 * Renders ApexCharts visualizations and KPI cards.
 */

let chartGeo = null;
let chartProd = null;
let chartAge = null;
let chartSeg = null;
let chartMLFeatures = null;

window.loadDashboardData = function() {
  // 1. Fetch KPIs
  fetch('/api/kpis')
    .then(res => res.json())
    .then(kpis => {
      document.getElementById('kpi-total-customers').innerText = kpis.total_customers.toLocaleString();
      document.getElementById('kpi-churn-rate').innerText = kpis.churn_rate_pct + '%';
      document.getElementById('kpi-capital-at-risk').innerText = '$' + kpis.capital_at_risk_usd.toLocaleString();
      document.getElementById('kpi-high-risk-count').innerText = kpis.high_risk_customers_count.toLocaleString();
      document.getElementById('kpi-avg-credit-score').innerText = kpis.avg_credit_score;
      document.getElementById('kpi-active-member-pct').innerText = kpis.active_members_pct + '%';
    })
    .catch(err => console.error('KPI Fetch Error:', err));

  // 2. Fetch Geography Chart Data
  fetch('/api/charts/geography')
    .then(res => res.json())
    .then(data => renderGeographyChart(data));

  // 3. Fetch Product Chart Data
  fetch('/api/charts/products')
    .then(res => res.json())
    .then(data => renderProductsChart(data));

  // 4. Fetch Age Chart Data
  fetch('/api/charts/age')
    .then(res => res.json())
    .then(data => renderAgeChart(data));

  // 5. Fetch Segment Chart Data
  fetch('/api/charts/segments')
    .then(res => res.json())
    .then(data => renderSegmentChart(data));

  // 6. Fetch ML Metrics Data
  fetch('/api/ml/metrics')
    .then(res => res.json())
    .then(data => renderMLMetrics(data));
};

function renderGeographyChart(data) {
  const categories = data.map(d => d.geography);
  const churnRates = data.map(d => d.churn_rate_pct);
  const totalCustomers = data.map(d => d.total_customers);

  const options = {
    series: [
      { name: 'Churn Rate %', type: 'column', data: churnRates },
      { name: 'Total Customers', type: 'line', data: totalCustomers }
    ],
    chart: { height: 280, type: 'line', toolbar: { show: false }, background: 'transparent' },
    stroke: { width: [0, 3], curve: 'smooth' },
    colors: ['#ef4444', '#3b82f6'],
    plotOptions: { bar: { columnWidth: '40%', borderRadius: 6 } },
    theme: { mode: 'dark' },
    xaxis: { categories: categories },
    yaxis: [
      { title: { text: 'Churn Rate %' } },
      { opposite: true, title: { text: 'Total Customers' } }
    ],
    tooltip: { shared: true, intersect: false }
  };

  if (chartGeo) chartGeo.destroy();
  chartGeo = new ApexCharts(document.querySelector("#chart-geography"), options);
  chartGeo.render();
}

function renderProductsChart(data) {
  const categories = data.map(d => d.num_of_products + ' Product(s)');
  const churnRates = data.map(d => d.churn_rate_pct);

  const options = {
    series: [{ name: 'Churn Rate %', data: churnRates }],
    chart: { height: 280, type: 'bar', toolbar: { show: false }, background: 'transparent' },
    plotOptions: { bar: { borderRadius: 6, distributed: true, columnWidth: '50%' } },
    colors: ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'],
    theme: { mode: 'dark' },
    legend: { show: false },
    xaxis: { categories: categories },
    yaxis: { title: { text: 'Churn Rate %' }, max: 100 }
  };

  if (chartProd) chartProd.destroy();
  chartProd = new ApexCharts(document.querySelector("#chart-products"), options);
  chartProd.render();
}

function renderAgeChart(data) {
  const categories = data.map(d => 'Age ' + d.age_group);
  const churnRates = data.map(d => d.churn_rate_pct);

  const options = {
    series: [{ name: 'Churn Rate %', data: churnRates }],
    chart: { height: 280, type: 'area', toolbar: { show: false }, background: 'transparent' },
    stroke: { curve: 'smooth', width: 3 },
    colors: ['#8b5cf6'],
    fill: { type: 'gradient', gradient: { shadeIntensity: 1, opacityFrom: 0.5, opacityTo: 0.05 } },
    theme: { mode: 'dark' },
    xaxis: { categories: categories },
    yaxis: { title: { text: 'Churn Rate %' } }
  };

  if (chartAge) chartAge.destroy();
  chartAge = new ApexCharts(document.querySelector("#chart-age"), options);
  chartAge.render();
}

function renderSegmentChart(data) {
  const labels = data.map(d => d.customer_segment);
  const series = data.map(d => d.total_balance);

  const options = {
    series: series,
    labels: labels,
    chart: { height: 280, type: 'donut', background: 'transparent' },
    colors: ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444'],
    theme: { mode: 'dark' },
    legend: { position: 'bottom' },
    tooltip: {
      y: { formatter: (val) => '$' + val.toLocaleString() }
    }
  };

  if (chartSeg) chartSeg.destroy();
  chartSeg = new ApexCharts(document.querySelector("#chart-segments"), options);
  chartSeg.render();
}

function renderMLMetrics(data) {
  // Render Feature Importances Chart
  const features = data.feature_importances.map(f => f.feature);
  const importances = data.feature_importances.map(f => (f.importance * 100).toFixed(1));

  const options = {
    series: [{ name: 'Importance %', data: importances }],
    chart: { height: 320, type: 'bar', toolbar: { show: false }, background: 'transparent' },
    plotOptions: { bar: { horizontal: true, borderRadius: 4, barHeight: '60%' } },
    colors: ['#3b82f6'],
    theme: { mode: 'dark' },
    xaxis: { categories: features, title: { text: 'Feature Importance %' } }
  };

  if (chartMLFeatures) chartMLFeatures.destroy();
  chartMLFeatures = new ApexCharts(document.querySelector("#chart-ml-features"), options);
  chartMLFeatures.render();

  // Render Performance Cards & Confusion Matrix
  const m = data.metrics;
  const cm = m.confusion_matrix;

  const html = `
    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 20px;">
      <div style="background: var(--bg-main); padding: 14px; border-radius: 8px; border: 1px solid var(--border-color);">
        <div style="font-size: 0.75rem; color: var(--text-secondary);">ROC-AUC SCORE</div>
        <div style="font-size: 1.4rem; font-weight: 700; color: var(--accent-success);">${(m.roc_auc * 100).toFixed(1)}%</div>
      </div>
      <div style="background: var(--bg-main); padding: 14px; border-radius: 8px; border: 1px solid var(--border-color);">
        <div style="font-size: 0.75rem; color: var(--text-secondary);">ACCURACY</div>
        <div style="font-size: 1.4rem; font-weight: 700; color: var(--accent-primary);">${(m.accuracy * 100).toFixed(1)}%</div>
      </div>
      <div style="background: var(--bg-main); padding: 14px; border-radius: 8px; border: 1px solid var(--border-color);">
        <div style="font-size: 0.75rem; color: var(--text-secondary);">PRECISION</div>
        <div style="font-size: 1.4rem; font-weight: 700; color: var(--accent-purple);">${(m.precision * 100).toFixed(1)}%</div>
      </div>
      <div style="background: var(--bg-main); padding: 14px; border-radius: 8px; border: 1px solid var(--border-color);">
        <div style="font-size: 0.75rem; color: var(--text-secondary);">RECALL (CHURN RECOVERY)</div>
        <div style="font-size: 1.4rem; font-weight: 700; color: var(--accent-warning);">${(m.recall * 100).toFixed(1)}%</div>
      </div>
    </div>

    <div style="font-weight: 700; font-size: 0.9rem; margin-bottom: 8px; color: var(--text-primary);">Confusion Matrix (20% Holdout Test Set)</div>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 0.82rem; text-align: center;">
      <div style="background: rgba(16, 185, 129, 0.15); padding: 12px; border-radius: 6px; border: 1px solid rgba(16, 185, 129, 0.3);">
        <strong style="color: var(--accent-success);">True Negative: ${cm.true_negative}</strong>
        <div style="font-size: 0.72rem; color: var(--text-muted);">Correctly Predicted Retained</div>
      </div>
      <div style="background: rgba(239, 68, 68, 0.15); padding: 12px; border-radius: 6px; border: 1px solid rgba(239, 68, 68, 0.3);">
        <strong style="color: var(--accent-danger);">False Positive: ${cm.false_positive}</strong>
        <div style="font-size: 0.72rem; color: var(--text-muted);">False Alarm Risk</div>
      </div>
      <div style="background: rgba(245, 158, 11, 0.15); padding: 12px; border-radius: 6px; border: 1px solid rgba(245, 158, 11, 0.3);">
        <strong style="color: var(--accent-warning);">False Negative: ${cm.false_negative}</strong>
        <div style="font-size: 0.72rem; color: var(--text-muted);">Missed Churn Opportunity</div>
      </div>
      <div style="background: rgba(59, 130, 246, 0.15); padding: 12px; border-radius: 6px; border: 1px solid rgba(59, 130, 246, 0.3);">
        <strong style="color: var(--accent-primary);">True Positive: ${cm.true_positive}</strong>
        <div style="font-size: 0.72rem; color: var(--text-muted);">Correctly Caught High Risk</div>
      </div>
    </div>
  `;

  document.getElementById('ml-metrics-container').innerHTML = html;
}
