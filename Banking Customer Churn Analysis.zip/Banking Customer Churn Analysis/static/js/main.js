/**
 * APEX FINANCIAL - MAIN APPLICATION CONTROLLER
 * Handles navigation, theme toggling, global filters, and API/Client-side fallback router.
 */

window.AppState = {
  currentView: 'dashboard',
  theme: 'dark',
  filters: {
    geography: 'All',
    segment: 'All'
  },
  customerData: [],
  kpis: {}
};

document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initThemeToggle();
  initGlobalFilters();
  initExportButton();
  
  // Initial Data Load
  loadDashboardData();
  loadETLLogs();
});

/* Navigation Router */
function initNavigation() {
  const navItems = document.querySelectorAll('.nav-item');
  const viewContainers = document.querySelectorAll('.view-container');
  const pageTitle = document.getElementById('page-title');
  const pageSubtitle = document.getElementById('page-subtitle');

  const titlesMap = {
    'dashboard': { title: 'Executive Banking Churn Dashboard', subtitle: 'Real-time Analytics, Predictive ML Risk Scoring, and Retention Strategy Engine' },
    'ml-analytics': { title: 'Machine Learning Churn Scoring', subtitle: 'Feature Importance, Confusion Matrix & Performance Metrics' },
    'customer-360': { title: 'Customer 360° Directory', subtitle: 'Comprehensive customer account directory with drill-down profiles' },
    'calculator': { title: 'Interactive Churn Risk Calculator', subtitle: 'Simulate single customer parameters to calculate churn probability and retention actions' },
    'sql-editor': { title: 'Live SQLite Query Engine', subtitle: 'Interactive SQL sandbox with pre-loaded business queries against banking database' },
    'statistics': { title: 'Statistical Analysis Suite', subtitle: 'Chi-Square independence tests, T-tests, and correlation heatmap' },
    'insights': { title: 'Executive Insights & Retention Strategy', subtitle: 'Auto-generated business insights, strategic takeaways, and ROI playbook' },
    'powerbi': { title: 'Power BI Embedded Canvas View', subtitle: 'Interactive layout canvas with cross-slicing visuals and DAX measures' },
    'etl': { title: 'Data Cleaning & ETL Audit Trail', subtitle: 'Automated pipeline log, missing value handling, and outlier screening' }
  };

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const view = item.getAttribute('data-view');
      if (!view) return;

      navItems.forEach(n => n.classList.remove('active'));
      item.classList.add('active');

      viewContainers.forEach(vc => vc.classList.remove('active'));
      const targetView = document.getElementById(`view-${view}`);
      if (targetView) targetView.classList.add('active');

      AppState.currentView = view;

      if (titlesMap[view]) {
        pageTitle.innerText = titlesMap[view].title;
        pageSubtitle.innerText = titlesMap[view].subtitle;
      }

      // Trigger lazy view initializers
      if (view === 'sql-editor' && window.initSQLEditor) window.initSQLEditor();
      if (view === 'customer-360' && window.loadCustomerTable) window.loadCustomerTable();
      if (view === 'statistics' && window.loadStatisticsView) window.loadStatisticsView();
      if (view === 'insights' && window.loadInsightsView) window.loadInsightsView();
      if (view === 'powerbi' && window.loadPowerBIView) window.loadPowerBIView();
    });
  });
}

/* Theme Toggle */
function initThemeToggle() {
  const toggleBtn = document.getElementById('theme-toggle');
  toggleBtn.addEventListener('click', () => {
    if (document.body.classList.contains('dark-mode')) {
      document.body.classList.remove('dark-mode');
      document.body.classList.add('light-mode');
      toggleBtn.innerHTML = '<span><i class="fa-solid fa-sun"></i> Light Theme</span> <i class="fa-solid fa-sliders"></i>';
      AppState.theme = 'light';
    } else {
      document.body.classList.remove('light-mode');
      document.body.classList.add('dark-mode');
      toggleBtn.innerHTML = '<span><i class="fa-solid fa-moon"></i> Dark Theme</span> <i class="fa-solid fa-sliders"></i>';
      AppState.theme = 'dark';
    }
  });
}

/* Global Filters */
function initGlobalFilters() {
  const geoFilter = document.getElementById('global-geo-filter');
  const segFilter = document.getElementById('global-segment-filter');

  geoFilter.addEventListener('change', (e) => {
    AppState.filters.geography = e.target.value;
    refreshCurrentView();
  });

  segFilter.addEventListener('change', (e) => {
    AppState.filters.segment = e.target.value;
    refreshCurrentView();
  });
}

function refreshCurrentView() {
  if (AppState.currentView === 'dashboard' && window.loadDashboardData) window.loadDashboardData();
  if (AppState.currentView === 'customer-360' && window.loadCustomerTable) window.loadCustomerTable();
}

/* Report Export Button */
function initExportButton() {
  const btn = document.getElementById('export-report-btn');
  btn.addEventListener('click', () => {
    window.open('/api/export/report', '_blank');
  });
}

/* Load ETL Logs */
function loadETLLogs() {
  fetch('/api/etl/status')
    .then(res => res.json())
    .then(logs => {
      const container = document.getElementById('etl-logs-list');
      if (container) {
        container.innerHTML = logs.map(log => `<li><i class="fa-solid fa-check" style="color: var(--accent-success);"></i> ${log}</li>`).join('');
      }
    })
    .catch(err => console.warn('Flask server ETL fetch fallback:', err));
}
