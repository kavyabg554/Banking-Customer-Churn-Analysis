/**
 * APEX FINANCIAL - CUSTOMER 360° DIRECTORY & PROFILES
 * Handles datatable pagination, searching, filters, and customer detail modal.
 */

let currentPage = 1;
let totalPages = 1;

window.loadCustomerTable = function(page = 1) {
  currentPage = page;
  const search = document.getElementById('cust-search-input')?.value || '';
  const risk = document.getElementById('cust-risk-filter')?.value || 'All';
  const geo = AppState.filters.geography || 'All';

  const url = `/api/customers?page=${page}&per_page=15&search=${encodeURIComponent(search)}&risk_tier=${risk}&geography=${geo}`;

  fetch(url)
    .then(res => res.json())
    .then(data => {
      renderTableRows(data.customers);
      totalPages = data.total_pages;
      document.getElementById('cust-pagination-info').innerText = `Showing page ${data.page} of ${data.total_pages} (${data.total_records.toLocaleString()} total customers)`;
    })
    .catch(err => console.error('Customer Table Fetch Error:', err));
};

document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('cust-search-input');
  const riskFilter = document.getElementById('cust-risk-filter');
  const prevBtn = document.getElementById('cust-prev-page');
  const nextBtn = document.getElementById('cust-next-page');
  const modalClose = document.getElementById('modal-close-btn');

  if (searchInput) {
    let timeout = null;
    searchInput.addEventListener('input', () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => window.loadCustomerTable(1), 300);
    });
  }

  if (riskFilter) {
    riskFilter.addEventListener('change', () => window.loadCustomerTable(1));
  }

  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      if (currentPage > 1) window.loadCustomerTable(currentPage - 1);
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      if (currentPage < totalPages) window.loadCustomerTable(currentPage + 1);
    });
  }

  if (modalClose) {
    modalClose.addEventListener('click', closeModal);
  }

  // Close modal when clicking backdrop
  const modalOverlay = document.getElementById('customer-modal');
  if (modalOverlay) {
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) closeModal();
    });
  }

  // Retention Button Action
  const retBtn = document.getElementById('trigger-retention-btn');
  if (retBtn) {
    retBtn.addEventListener('click', () => {
      retBtn.innerHTML = '<i class="fa-solid fa-check"></i> Retention Intervention Deployed!';
      retBtn.classList.remove('btn-primary');
      retBtn.classList.add('btn-success');
      setTimeout(() => {
        retBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Deploy Retention Offer';
        retBtn.classList.remove('btn-success');
        retBtn.classList.add('btn-primary');
        closeModal();
      }, 1500);
    });
  }
});

function renderTableRows(customers) {
  const tbody = document.getElementById('customer-table-body');
  if (!tbody) return;

  if (customers.length === 0) {
    tbody.innerHTML = '<tr><td colspan="10" style="text-align: center; padding: 20px; color: var(--text-muted);">No customers found matching filter criteria.</td></tr>';
    return;
  }

  tbody.innerHTML = customers.map(c => {
    const riskPct = (c.risk_score * 100).toFixed(1);
    let badgeClass = 'low';
    if (c.risk_score >= 0.65) badgeClass = 'high';
    else if (c.risk_score >= 0.35) badgeClass = 'medium';

    const statusBadge = c.exited === 1 
      ? '<span style="color: var(--accent-danger); font-weight: 600;"><i class="fa-solid fa-user-xmark"></i> Exited</span>'
      : '<span style="color: var(--accent-success); font-weight: 600;"><i class="fa-solid fa-user-check"></i> Active</span>';

    return `
      <tr>
        <td style="font-family: var(--font-mono); font-weight: 500;">#${c.customer_id}</td>
        <td style="font-weight: 600;">${c.surname}</td>
        <td>${c.geography}</td>
        <td>${c.age}</td>
        <td>${c.credit_score}</td>
        <td style="font-family: var(--font-mono); font-weight: 600;">$${c.balance.toLocaleString()}</td>
        <td>${c.num_of_products}</td>
        <td>${statusBadge}</td>
        <td><span class="badge-risk ${badgeClass}">${riskPct}%</span></td>
        <td>
          <button class="btn btn-secondary" style="padding: 4px 10px; font-size: 0.78rem;" onclick="openCustomerModal(${c.customer_id})">
            <i class="fa-solid fa-eye"></i> View Profile
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

window.openCustomerModal = function(id) {
  fetch(`/api/customers/${id}`)
    .then(res => res.json())
    .then(c => {
      document.getElementById('modal-cust-name').innerText = `${c.surname} (Customer 360° Profile)`;
      document.getElementById('modal-cust-id').innerText = `ID: #${c.customer_id} • Segment: ${c.customer_segment}`;
      
      document.getElementById('modal-geo').innerText = c.geography;
      document.getElementById('modal-age').innerText = c.age;
      document.getElementById('modal-gender').innerText = c.gender;
      document.getElementById('modal-credit').innerText = c.credit_score;
      document.getElementById('modal-balance').innerText = '$' + c.balance.toLocaleString();
      document.getElementById('modal-products').innerText = c.num_of_products;
      document.getElementById('modal-active').innerText = c.is_active_member === 1 ? 'Yes (Active)' : 'No (Inactive)';
      document.getElementById('modal-segment').innerText = c.customer_segment;

      const ra = c.risk_analysis;
      const modalBadge = document.getElementById('modal-risk-badge');
      modalBadge.className = `badge-risk ${ra.badge_color}`;
      modalBadge.innerText = `${ra.risk_category} (${ra.risk_score_pct}%)`;

      document.getElementById('modal-risk-factors-list').innerHTML = ra.risk_factors.map(rf => `<li>${rf}</li>`).join('');
      document.getElementById('modal-retention-rec').innerText = ra.recommended_strategy;

      const modalOverlay = document.getElementById('customer-modal');
      if (modalOverlay) modalOverlay.classList.add('active');
    })
    .catch(err => console.error('Customer Detail Modal Fetch Error:', err));
};

function closeModal() {
  const modalOverlay = document.getElementById('customer-modal');
  if (modalOverlay) modalOverlay.classList.remove('active');
}
