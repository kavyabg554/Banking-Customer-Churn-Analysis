/**
 * APEX FINANCIAL - STATISTICAL ANALYSIS SUITE
 * Renders Chi-Square independence tests, T-tests, and correlation heatmap.
 */

let chartCorr = null;

window.loadStatisticsView = function() {
  fetch('/api/statistics')
    .then(res => res.json())
    .then(data => {
      renderChi2Tests(data.tests);
      renderTTests(data.tests);
      renderCorrelationHeatmap(data.correlation);
    })
    .catch(err => console.error('Statistics Fetch Error:', err));
};

function renderChi2Tests(tests) {
  const container = document.getElementById('stats-chi2-container');
  if (!container) return;

  const chiKeys = ['geography_chi2', 'is_active_member_chi2', 'num_of_products_chi2'];

  container.innerHTML = chiKeys.map(k => {
    const item = tests[k];
    const sigClass = item.is_statistically_significant ? 'color: var(--accent-success);' : 'color: var(--text-muted);';
    const sigBadge = item.is_statistically_significant 
      ? '<span class="status-pill" style="font-size: 0.7rem; padding: 2px 8px;"><i class="fa-solid fa-check"></i> Statistically Significant (p < 0.05)</span>'
      : '<span style="font-size: 0.7rem; color: var(--text-muted);">Not Significant</span>';

    return `
      <div style="background: var(--bg-main); padding: 14px; border-radius: 8px; border: 1px solid var(--border-color);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
          <div style="font-weight: 700; font-size: 0.9rem; color: var(--text-primary);">${item.feature} vs Churn</div>
          ${sigBadge}
        </div>
        <div style="display: flex; gap: 16px; font-size: 0.82rem; color: var(--text-secondary); margin-bottom: 6px;">
          <div>Chi² Stat: <strong style="color: var(--accent-primary);">${item.chi2_stat}</strong></div>
          <div>p-value: <strong style="${sigClass}">${item.p_value < 0.001 ? '< 0.001' : item.p_value.toFixed(4)}</strong></div>
          <div>DoF: <strong>${item.dof}</strong></div>
        </div>
        <div style="font-size: 0.8rem; color: var(--text-muted); italic;">${item.conclusion}</div>
      </div>
    `;
  }).join('');
}

function renderTTests(tests) {
  const container = document.getElementById('stats-ttest-container');
  if (!container) return;

  const tKeys = ['age_ttest', 'balance_ttest'];

  container.innerHTML = tKeys.map(k => {
    const item = tests[k];
    return `
      <div style="background: var(--bg-main); padding: 14px; border-radius: 8px; border: 1px solid var(--border-color);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
          <div style="font-weight: 700; font-size: 0.9rem; color: var(--text-primary);">${item.feature} (T-Test)</div>
          <span class="status-pill" style="font-size: 0.7rem; padding: 2px 8px;"><i class="fa-solid fa-check"></i> p < 0.0001</span>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 0.82rem; margin-bottom: 6px;">
          <div>Mean Exited: <strong style="color: var(--accent-danger);">${item.mean_exited}</strong></div>
          <div>Mean Retained: <strong style="color: var(--accent-success);">${item.mean_retained}</strong></div>
        </div>
        <div style="font-size: 0.8rem; color: var(--text-secondary);">t-statistic: <strong>${item.t_statistic}</strong></div>
        <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 4px;">${item.conclusion}</div>
      </div>
    `;
  }).join('');
}

function renderCorrelationHeatmap(corrData) {
  const cols = corrData.columns;
  const matrix = corrData.matrix;

  const series = cols.map((colName, rowIndex) => {
    return {
      name: colName,
      data: matrix[rowIndex].map((val, colIndex) => {
        return {
          x: cols[colIndex],
          y: val
        };
      })
    };
  });

  const options = {
    series: series,
    chart: { height: 380, type: 'heatmap', toolbar: { show: false }, background: 'transparent' },
    colors: ["#3b82f6"],
    dataLabels: { enabled: true, style: { colors: ['#fff'], fontSize: '10px' } },
    xaxis: { type: 'category' },
    theme: { mode: 'dark' }
  };

  if (chartCorr) chartCorr.destroy();
  chartCorr = new ApexCharts(document.querySelector("#chart-correlation"), options);
  chartCorr.render();
}
