/**
 * APEX FINANCIAL - LIVE SQL QUERY ENGINE
 * Handles pre-loaded SQL templates, query execution, and tabular rendering.
 */

let lastQueryResult = null;

window.initSQLEditor = function() {
  loadSQLTemplates();

  const runBtn = document.getElementById('run-sql-btn');
  const exportBtn = document.getElementById('export-sql-csv-btn');

  if (runBtn) runBtn.onclick = executeCurrentQuery;
  if (exportBtn) exportBtn.onclick = exportSQLResultCSV;
};

function loadSQLTemplates() {
  fetch('/api/sql/templates')
    .then(res => res.json())
    .then(templates => {
      const container = document.getElementById('sql-templates-list');
      if (!container) return;

      container.innerHTML = templates.map(t => `
        <button class="sql-template-btn" onclick="selectSQLTemplate(\`${escapeQuery(t.query)}\`)">
          <div style="font-weight: 600; font-size: 0.8rem; margin-bottom: 2px;">#${t.id}: ${t.title}</div>
          <div style="font-size: 0.72rem; color: var(--text-muted); font-family: var(--font-mono); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${t.query.split('\n')[0]}</div>
        </button>
      `).join('');
    })
    .catch(err => console.error('SQL Templates Error:', err));
}

function escapeQuery(str) {
  return str.replace(/`/g, '\\`').replace(/\n/g, ' ');
}

window.selectSQLTemplate = function(query) {
  const textarea = document.getElementById('sql-textarea');
  if (textarea) {
    textarea.value = query;
    executeCurrentQuery();
  }
};

function executeCurrentQuery() {
  const textarea = document.getElementById('sql-textarea');
  const statusEl = document.getElementById('sql-result-status');
  const outputEl = document.getElementById('sql-table-output');

  if (!textarea || !statusEl || !outputEl) return;

  const query = textarea.value.trim();
  if (!query) return;

  statusEl.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Executing query on SQLite engine...';

  fetch('/api/sql/execute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query: query })
  })
  .then(res => res.json())
  .then(res => {
    if (!res.success) {
      statusEl.innerHTML = `<span style="color: var(--accent-danger);"><i class="fa-solid fa-circle-xmark"></i> SQL Error: ${res.error}</span>`;
      outputEl.innerHTML = `<div style="padding: 16px; color: var(--accent-danger); font-family: var(--font-mono); font-size: 0.85rem; background: rgba(239,68,68,0.1); border-radius: 8px;">${res.error}</div>`;
      return;
    }

    lastQueryResult = res;
    statusEl.innerHTML = `<span style="color: var(--accent-success);"><i class="fa-solid fa-circle-check"></i> Query Executed Successfully • ${res.row_count} rows returned in ${res.execution_time_ms} ms</span>`;

    renderSQLResultTable(res.columns, res.rows);
  })
  .catch(err => {
    statusEl.innerHTML = `<span style="color: var(--accent-danger);"><i class="fa-solid fa-circle-xmark"></i> Failed to execute query.</span>`;
  });
}

function renderSQLResultTable(columns, rows) {
  const outputEl = document.getElementById('sql-table-output');
  if (!outputEl) return;

  if (rows.length === 0) {
    outputEl.innerHTML = '<div style="padding: 20px; color: var(--text-muted);">No records found.</div>';
    return;
  }

  let html = '<table class="styled-table"><thead><tr>';
  columns.forEach(col => {
    html += `<th>${col}</th>`;
  });
  html += '</tr></thead><tbody>';

  rows.forEach(row => {
    html += '<tr>';
    row.forEach(cell => {
      html += `<td>${cell}</td>`;
    });
    html += '</tr>';
  });

  html += '</tbody></table>';
  outputEl.innerHTML = html;
}

function exportSQLResultCSV() {
  if (!lastQueryResult || !lastQueryResult.rows) return;

  let csv = lastQueryResult.columns.join(',') + '\n';
  lastQueryResult.rows.forEach(row => {
    csv += row.map(v => `"${v}"`).join(',') + '\n';
  });

  const blob = new Blob([csv], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'sql_query_export.csv';
  a.click();
}
