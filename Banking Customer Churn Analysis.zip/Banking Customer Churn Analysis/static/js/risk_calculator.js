/**
 * APEX FINANCIAL - INTERACTIVE RISK CALCULATOR
 * Real-time Churn Risk Simulator & Retention Action Engine.
 */

let gaugeChart = null;

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('risk-calc-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      calculateRisk();
    });

    // Run initial calculation
    calculateRisk();
  }
});

function calculateRisk() {
  const payload = {
    age: document.getElementById('calc-age').value,
    geography: document.getElementById('calc-geo').value,
    credit_score: document.getElementById('calc-credit').value,
    balance: document.getElementById('calc-balance').value,
    num_of_products: document.getElementById('calc-products').value,
    is_active_member: document.getElementById('calc-active').value,
    estimated_salary: document.getElementById('calc-salary').value,
    gender: document.getElementById('calc-gender').value
  };

  fetch('/api/ml/predict', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  .then(res => res.json())
  .then(res => renderRiskResult(res))
  .catch(err => console.error('Risk Calculation Error:', err));
}

function renderRiskResult(data) {
  // Render Radial Gauge
  const score = data.risk_score_pct;

  const options = {
    series: [score],
    chart: { height: 220, type: 'radialBar', background: 'transparent' },
    plotOptions: {
      radialBar: {
        hollow: { size: '65%' },
        dataLabels: {
          name: { show: true, fontSize: '0.8rem', color: '#9ca3af', offsetY: -10 },
          value: { show: true, fontSize: '1.8rem', fontWeight: '700', color: '#fff', offsetY: 5, formatter: (v) => v + '%' }
        },
        track: { background: 'rgba(255, 255, 255, 0.08)' }
      }
    },
    colors: [score >= 65 ? '#ef4444' : (score >= 35 ? '#f59e0b' : '#10b981')],
    labels: ['CHURN RISK']
  };

  if (gaugeChart) gaugeChart.destroy();
  gaugeChart = new ApexCharts(document.querySelector("#chart-gauge"), options);
  gaugeChart.render();

  // Badge
  const badge = document.getElementById('calc-risk-badge');
  badge.className = `badge-risk ${data.badge_color}`;
  badge.innerText = `${data.risk_category} (${score}%)`;

  // Risk Factors
  const factorsList = document.getElementById('calc-risk-factors');
  factorsList.innerHTML = data.risk_factors.map(rf => `<li>${rf}</li>`).join('');

  // Recommended Action
  document.getElementById('calc-recommended-action').innerText = data.recommended_strategy;
}
