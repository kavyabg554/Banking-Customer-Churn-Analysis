/**
 * APEX FINANCIAL - POWER BI CANVAS & INSIGHTS RENDERER
 * Embedded Power BI dashboard canvas and automated business insights renderer.
 */

window.loadInsightsView = function() {
  fetch('/api/insights')
    .then(res => res.json())
    .then(insights => {
      const container = document.getElementById('insights-list-container');
      if (!container) return;

      container.innerHTML = insights.map(ins => `
        <div class="insight-card ${ins.severity}">
          <div class="insight-title">
            <i class="fa-solid fa-triangle-exclamation" style="color: var(--accent-${ins.severity === 'critical' ? 'danger' : (ins.severity === 'high' ? 'warning' : 'primary')});"></i>
            ${ins.title}
          </div>
          <div class="insight-desc">${ins.description}</div>
          <div class="insight-rec"><i class="fa-solid fa-lightbulb"></i> Strategic Action: ${ins.recommendation}</div>
        </div>
      `).join('');
    })
    .catch(err => console.error('Insights Fetch Error:', err));
};

window.loadPowerBIView = function() {
  const container = document.getElementById('powerbi-canvas-content');
  if (!container) return;

  const html = `
    <div style="background: #181d28; padding: 20px; border-radius: 12px; border: 1px solid #2d3748;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; border-bottom: 1px solid #2d3748; padding-bottom: 12px;">
        <div style="font-family: var(--font-heading); font-size: 1.1rem; font-weight: 700; color: #f2c811;">
          <i class="fa-solid fa-chart-column"></i> DAX Measures Matrix & Slicers Summary
        </div>
        <span class="status-pill" style="background: rgba(242, 200, 17, 0.15); color: #f2c811; border-color: rgba(242, 200, 17, 0.3);">
          Power BI Desktop v2.126 Ready
        </span>
      </div>

      <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 20px;">
        <div style="background: #0f131c; padding: 14px; border-radius: 8px; border-left: 4px solid #f2c811;">
          <div style="font-size: 0.75rem; color: #a0aec0;">DAX MEASURE</div>
          <div style="font-weight: 700; font-size: 0.95rem; color: #fff;">[Total Customers]</div>
          <div style="font-family: var(--font-mono); font-size: 0.75rem; color: #4a5568; margin-top: 4px;">COUNT(customers[customer_id])</div>
        </div>
        <div style="background: #0f131c; padding: 14px; border-radius: 8px; border-left: 4px solid #ef4444;">
          <div style="font-size: 0.75rem; color: #a0aec0;">DAX MEASURE</div>
          <div style="font-weight: 700; font-size: 0.95rem; color: #fff;">[Churn Rate %]</div>
          <div style="font-family: var(--font-mono); font-size: 0.75rem; color: #4a5568; margin-top: 4px;">DIVIDE(CALCULATE(COUNT(...), exited=1), COUNT(...))</div>
        </div>
        <div style="background: #0f131c; padding: 14px; border-radius: 8px; border-left: 4px solid #3b82f6;">
          <div style="font-size: 0.75rem; color: #a0aec0;">DAX MEASURE</div>
          <div style="font-weight: 700; font-size: 0.95rem; color: #fff;">[Capital At Risk]</div>
          <div style="font-family: var(--font-mono); font-size: 0.75rem; color: #4a5568; margin-top: 4px;">CALCULATE(SUM(balance), exited=1)</div>
        </div>
      </div>

      <div style="font-weight: 600; font-size: 0.9rem; margin-bottom: 10px; color: #fff;">Regional Performance Power BI Matrix Visual</div>
      <div class="data-table-wrapper">
        <table class="styled-table">
          <thead>
            <tr>
              <th>Geography</th>
              <th>Total Customers</th>
              <th>Churned Count</th>
              <th>Churn Rate %</th>
              <th>Avg Balance ($)</th>
              <th>Capital At Risk ($)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="font-weight: 600; color: #f2c811;">Germany</td>
              <td>2,509</td>
              <td>814</td>
              <td><span class="badge-risk high">32.4%</span></td>
              <td>$119,730</td>
              <td>$97,460,220</td>
            </tr>
            <tr>
              <td style="font-weight: 600; color: #3b82f6;">France</td>
              <td>5,014</td>
              <td>810</td>
              <td><span class="badge-risk low">16.15%</span></td>
              <td>$62,090</td>
              <td>$50,292,900</td>
            </tr>
            <tr>
              <td style="font-weight: 600; color: #10b981;">Spain</td>
              <td>2,477</td>
              <td>413</td>
              <td><span class="badge-risk low">16.67%</span></td>
              <td>$61,810</td>
              <td>$25,527,530</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `;

  container.innerHTML = html;

  const btn = document.getElementById('download-powerbi-json');
  if (btn) {
    btn.onclick = () => {
      window.open('/api/export/powerbi', '_blank');
    };
  }
};
