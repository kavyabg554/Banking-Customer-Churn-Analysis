# 🏦 Apex Financial - Banking Customer Churn Analytics BI Suite

> **Corporate-Grade End-to-End Banking Sales & Customer Churn Analytics BI Dashboard, Machine Learning Risk Scoring Engine, Live SQL Query Playground, and Statistical Hypothesis Testing Suite.**

---

## 🌟 Executive Overview & Key Highlights

This application is a production-ready, full-stack **Banking Customer Churn Analytics Platform** built with **Python, Pandas, SQLite, Scipy/Statsmodels, Scikit-Learn, Flask, ApexCharts, and Modern Vanilla CSS/JS**. It addresses the critical banking challenge of **customer attrition & capital loss**, providing real-time data science workflows, predictive ML risk scoring, interactive SQL sandbox capabilities, and automated ROI retention strategies.

### Key Capabilities:
- 📊 **Executive BI Dashboard:** 6 real-time KPI cards, ApexCharts visualizations for regional geography, age demographics, customer segmentation, and product friction.
- 🤖 **Predictive ML Risk Engine:** Machine learning Random Forest classifier evaluating churn probability (AUC = 0.86) with real-time risk tier badges, feature importances, and confusion matrix audit.
- 👥 **Customer 360° Directory & Profiles:** Searchable datatable across 10,000 banking customers with drill-down modals, risk factor breakdown, and one-click retention action deployment.
- 🧮 **Statistical Hypothesis Testing Suite:** Automated Chi-Square tests of independence, independent two-sample T-tests, and Pearson correlation matrix heatmaps proving statistical significance ($p < 0.001$).
- 💻 **Live SQLite Query Playground:** Embedded SQL sandbox with syntax highlighting, pre-loaded business queries (High-value at-risk, salary quintiles, branch performance), execution metrics (ms), and CSV export.
- ⚡ **Interactive Risk Simulator:** Input custom customer demographics to simulate churn risk, generate radial probability gauges, and receive tailored retention offers.
- 📈 **Power BI Embedded Canvas:** Power BI desktop visual matrix replica with DAX measure formulas (`DIVIDE`, `CALCULATE`, `SUM`) and one-click JSON dataset schema export.
- 🧹 **ETL & Data Cleaning Pipeline:** Automated missing value imputation, IQR outlier screening, and feature engineering.

---

## 🏗️ Architecture & Technology Stack

```
f:/Banking Customer Churn Analysis/
│
├── app.py                      # Flask Server & REST API endpoints
├── config.py                   # Global thresholds & ML hyperparameters
├── requirements.txt            # Python dependencies
│
├── data/
│   ├── generate_dataset.py     # Python script generating 10,000 customer records
│   ├── schema.sql              # SQLite DDL schema, indexes, and analytical views
│   └── banking_churn.db        # Production SQLite Database
│
├── modules/
│   ├── db_engine.py            # Thread-safe SQLite executor & custom SQL sandbox
│   ├── data_cleaner.py         # Automated ETL data cleaner & IQR outlier detector
│   ├── analytics_engine.py     # Pandas KPI aggregator & Scipy statistical tests
│   ├── ml_scoring.py           # Machine learning model & single-customer predictor
│   └── report_generator.py     # Executive insights generator & report exporters
│
├── static/
│   ├── css/
│   │   └── styles.css          # Executive Dark/Light Banking UI design system
│   └── js/
│       ├── main.js             # Navigation, theme toggle, and global router
│       ├── dashboard.js        # ApexCharts initialization & KPI cards
│       ├── sql_editor.js       # SQL playground & templates
│       ├── risk_calculator.js  # Interactive risk calculator & radial gauge
│       ├── customer_360.js     # Searchable directory & modal deep-dive
│       ├── statistics.js       # Statistical hypothesis cards & correlation heatmap
│       └── powerbi_view.js     # Power BI canvas replica & insights renderer
│
└── templates/
    └── index.html              # Main Single-Page Application (SPA) HTML layout
```

---

## 📊 Core Business Analytics & Insights

1. **German Regional Exposure:** Customers located in **Germany** exhibit a **32.4% churn rate**, which is double the churn rate of France (16.15%) and Spain (16.67%). Germany represents over **$97M in total capital at risk**.
2. **The Multi-Product Paradox:** Holding 2 products produces the lowest churn rate (7.5%), whereas holding 3 or 4 products results in extreme churn rates exceeding **85%**, pointing to product over-bundling and account complexity friction.
3. **Age Cohort Friction:** Customers aged **45 to 65 years** churn at 2.4x the rate of customers under 35, highlighting wealth transfer to competitor institutions during pre-retirement.
4. **Member Inactivity:** Inactive bank members account for over **62% of all lost accounts**, making account dormancy the #1 leading indicator before attrition.

---

## 🧮 Statistical Methodologies Applied

### 1. Chi-Square Test of Independence ($\chi^2$)
Calculated across categorical features against churn status (`exited`):
- **Geography vs Exited:** $\chi^2 = 301.2, p < 0.0001, \text{DoF} = 2$ (Statistically Significant)
- **Active Membership vs Exited:** $\chi^2 = 248.7, p < 0.0001, \text{DoF} = 1$ (Statistically Significant)
- **Number of Products vs Exited:** $\chi^2 = 1503.4, p < 0.0001, \text{DoF} = 3$ (Statistically Significant)

### 2. Independent Two-Sample T-Test ($t$)
Calculated between Exited ($N=2,037$) and Retained ($N=7,963$) groups:
- **Age:** $t = 28.52, p < 0.0001$ ($\text{Mean}_{\text{Exited}} = 44.8 \text{ yrs}$ vs $\text{Mean}_{\text{Retained}} = 37.4 \text{ yrs}$)
- **Balance:** $t = 11.83, p < 0.0001$ ($\text{Mean}_{\text{Exited}} = \$91,108.50$ vs $\text{Mean}_{\text{Retained}} = \$72,745.20$)

---

## 💻 Sample SQL Queries (Pre-loaded in SQL Engine)

### High-Value At-Risk Customers
```sql
SELECT 
    customer_id, surname, geography, gender, age, balance, credit_score, risk_score
FROM customers
WHERE balance >= 100000 AND is_active_member = 0 AND exited = 0
ORDER BY balance DESC
LIMIT 15;
```

### Multi-Product Churn Paradox Analysis
```sql
SELECT 
    num_of_products,
    COUNT(*) AS total_customers,
    SUM(exited) AS churned_customers,
    ROUND(AVG(exited) * 100.0, 2) AS churn_rate_pct,
    ROUND(AVG(balance), 2) AS avg_balance
FROM customers
GROUP BY num_of_products
ORDER BY num_of_products ASC;
```

---

## 🚀 How to Run the Application

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Initialize Database & Generate 10,000 Records
```bash
python data/generate_dataset.py
```

### 3. Launch the Flask Web Application
```bash
python app.py
```
Open your browser and navigate to: `http://localhost:5000`

---

## 🎓 Portfolio & Interview Quick Guide

- **Data Analyst Questions:** Focus on the SQL queries, Chi-Square/T-Test interpretation, DAX measure calculations, and business recommendations for Germany branch retention.
- **Data Scientist / ML Questions:** Focus on feature encoding, Random Forest hyperparameters (`n_estimators=100, max_depth=10, class_weight='balanced'`), ROC-AUC evaluation, and risk factor identification logic.
- **Software Engineer Questions:** Highlight the RESTful API architecture, thread-safe SQLite connection pooling, SQL injection prevention, clean JavaScript component isolation, and glassmorphism CSS styling.

---
*Developed by Apex Analytics Team. Portfolio & Production Ready.*
