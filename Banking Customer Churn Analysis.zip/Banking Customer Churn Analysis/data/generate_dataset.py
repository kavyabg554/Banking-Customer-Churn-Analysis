import os
import sqlite3
import random
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

# Import config paths
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

def generate_banking_data(num_samples=10000, seed=42):
    """Generates realistic banking customer dataset with realistic churn drivers."""
    np.random.seed(seed)
    random.seed(seed)
    
    surnames = [
        'Hargrave', 'Hill', 'Onio', 'Boni', 'Mitchell', 'Chu', 'Bartlett', 'Chidinnma',
        'Weigel', 'Golospink', 'Macdonald', 'Fanucci', 'Ying', 'Schmidt', 'Muller',
        'Weber', 'Hoffmann', 'Schulz', 'Koch', 'Bauer', 'Richter', 'Klein', 'Wolf',
        'Dupont', 'Martin', 'Bernard', 'Dubois', 'Thomas', 'Robert', 'Richard',
        'Petit', 'Durand', 'Leroy', 'Moreau', 'García', 'Rodríguez', 'González',
        'Fernández', 'López', 'Martínez', 'Sánchez', 'Pérez', 'Gómez', 'Martin'
    ]
    
    geographies = ['France', 'Germany', 'Spain']
    geo_weights = [0.50, 0.25, 0.25]
    
    genders = ['Female', 'Male']
    account_types = ['Savings', 'Checking', 'Investment', 'Private Banking']
    preferred_channels = ['Mobile App', 'Online Banking', 'Branch', 'Phone']
    branch_codes = ['BR-PAR-01', 'BR-FRA-02', 'BR-MAD-03', 'BR-BER-04', 'BR-LYO-05', 'BR-BAR-06']
    
    data = []
    
    start_date = datetime(2025, 1, 1)
    
    for i in range(1, num_samples + 1):
        customer_id = 15600000 + i
        surname = random.choice(surnames)
        geography = np.random.choice(geographies, p=geo_weights)
        gender = random.choice(genders)
        
        # Age distribution: mean 38, std 10.5, clamped between 18 and 85
        age = int(np.clip(np.random.normal(38.9, 10.5), 18, 85))
        
        # Credit Score: mean 650, std 96, clamped 350-850
        credit_score = int(np.clip(np.random.normal(650, 96), 350, 850))
        
        # Tenure: 0 to 10 years
        tenure = random.randint(0, 10)
        
        # Balance distribution
        # France/Spain have some zero balances, Germany mostly has positive balance
        if geography == 'Germany':
            balance = round(float(np.random.normal(119000, 30000)), 2)
            balance = max(25000.0, balance)
        else:
            if random.random() < 0.35:
                balance = 0.0
            else:
                balance = round(float(np.random.normal(90000, 35000)), 2)
                balance = max(1000.0, balance)
                
        # Number of products: 1, 2, 3, 4
        num_of_products = np.random.choice([1, 2, 3, 4], p=[0.50, 0.43, 0.05, 0.02])
        
        has_cr_card = 1 if random.random() < 0.705 else 0
        is_active_member = 1 if random.random() < 0.515 else 0
        
        # Estimated Salary: $11,000 to $200,000 uniform/normal mix
        estimated_salary = round(float(np.random.uniform(12000, 199000)), 2)
        
        # Auxiliary banking variables
        transaction_freq = random.randint(1, 45) if is_active_member else random.randint(0, 5)
        account_type = random.choice(account_types)
        preferred_channel = random.choice(preferred_channels)
        complaints_count = int(np.random.choice([0, 1, 2, 3, 4], p=[0.75, 0.15, 0.06, 0.03, 0.01]))
        nps_score = random.randint(1, 6) if complaints_count > 0 else random.randint(6, 10)
        debt_to_income = round(float(np.random.uniform(0.05, 0.65)), 3)
        branch_code = random.choice(branch_codes)
        
        # Segment calculation
        if balance > 150000 and estimated_salary > 120000:
            segment = 'VIP High Net Worth'
        elif age >= 55 and balance > 80000:
            segment = 'Retiring Wealthy'
        elif age <= 35 and estimated_salary > 60000:
            segment = 'Young Professional'
        elif is_active_member == 0 and transaction_freq <= 2:
            segment = 'At-Risk Dormant'
        else:
            segment = 'Mid-Market Standard'
            
        # Realistic Churn Logic (Ground Truth Exited probability calculation)
        # Base log-odds
        logit = -2.3
        
        # Age effect (older customers churn more)
        logit += (age - 38) * 0.065
        
        # Geography effect (Germany has significantly higher churn)
        if geography == 'Germany':
            logit += 0.85
        elif geography == 'Spain':
            logit += 0.10
            
        # Gender effect (Female higher churn)
        if gender == 'Female':
            logit += 0.45
            
        # Active member effect (Inactive churns much more)
        if is_active_member == 0:
            logit += 0.75
            
        # Number of products effect (1 product baseline, 2 product lowest, 3 & 4 extreme high churn)
        if num_of_products == 2:
            logit -= 0.60
        elif num_of_products == 3:
            logit += 1.80
        elif num_of_products == 4:
            logit += 3.20
            
        # Complaints effect
        logit += complaints_count * 0.55
        
        # Balance effect (High balance + inactive = churn driver)
        if balance > 100000 and is_active_member == 0:
            logit += 0.40
            
        # Credit score effect (Very low credit score churns more)
        if credit_score < 450:
            logit += 0.50
            
        prob_churn = 1.0 / (1.0 + np.exp(-logit))
        exited = 1 if random.random() < prob_churn else 0
        
        # Risk score (0.0 to 1.0)
        risk_score = round(float(prob_churn), 4)
        
        days_ago = random.randint(1, 90) if is_active_member else random.randint(60, 365)
        last_tx_date = (start_date + timedelta(days=random.randint(0, 365) - days_ago)).strftime('%Y-%m-%d')
        
        row = (
            customer_id, surname, credit_score, geography, gender, age, tenure,
            balance, num_of_products, has_cr_card, is_active_member,
            estimated_salary, exited, risk_score, transaction_freq, account_type,
            preferred_channel, complaints_count, nps_score, debt_to_income,
            branch_code, segment, last_tx_date
        )
        data.append(row)
        
    df = pd.DataFrame(data, columns=[
        'customer_id', 'surname', 'credit_score', 'geography', 'gender', 'age',
        'tenure', 'balance', 'num_of_products', 'has_cr_card', 'is_active_member',
        'estimated_salary', 'exited', 'risk_score', 'transaction_frequency_monthly',
        'account_type', 'preferred_channel', 'complaints_count', 'nps_score',
        'debt_to_income_ratio', 'branch_code', 'customer_segment', 'last_transaction_date'
    ])
    
    return df

def build_database():
    """Generates dataset and initializes SQLite database."""
    print("Generating 10,000 realistic customer churn records...")
    df = generate_banking_data(num_samples=10000)
    
    os.makedirs(config.DATA_DIR, exist_ok=True)
    
    # Write CSV for fallback & raw analysis
    csv_path = os.path.join(config.DATA_DIR, 'banking_churn.csv')
    df.to_csv(csv_path, index=False)
    print(f"Dataset exported to CSV: {csv_path}")
    
    # Initialize SQLite DB
    conn = sqlite3.connect(config.DB_PATH)
    
    # Run Schema SQL
    with open(config.SCHEMA_PATH, 'r') as f:
        schema_sql = f.read()
    conn.executescript(schema_sql)
    
    # Insert Data into SQL
    df.to_sql('customers', conn, if_exists='append', index=False)
    conn.commit()
    conn.close()
    print(f"Database successfully created at {config.DB_PATH} with {len(df)} records!")

if __name__ == '__main__':
    build_database()
