-- Banking Customer Churn Analytics Database Schema
-- Database: banking_churn.db

DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS retention_actions;
DROP VIEW IF EXISTS view_churn_summary;
DROP VIEW IF EXISTS view_high_risk_high_value;

CREATE TABLE customers (
    customer_id INTEGER PRIMARY KEY,
    surname TEXT NOT NULL,
    credit_score INTEGER NOT NULL,
    geography TEXT NOT NULL,
    gender TEXT NOT NULL,
    age INTEGER NOT NULL,
    tenure INTEGER NOT NULL,
    balance REAL NOT NULL,
    num_of_products INTEGER NOT NULL,
    has_cr_card INTEGER NOT NULL,
    is_active_member INTEGER NOT NULL,
    estimated_salary REAL NOT NULL,
    exited INTEGER NOT NULL,
    risk_score REAL NOT NULL,
    transaction_frequency_monthly INTEGER NOT NULL,
    account_type TEXT NOT NULL,
    preferred_channel TEXT NOT NULL,
    complaints_count INTEGER NOT NULL,
    nps_score INTEGER NOT NULL,
    debt_to_income_ratio REAL NOT NULL,
    branch_code TEXT NOT NULL,
    customer_segment TEXT NOT NULL,
    last_transaction_date TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexing for high-performance SQL analytics
CREATE INDEX idx_customers_geography ON customers(geography);
CREATE INDEX idx_customers_exited ON customers(exited);
CREATE INDEX idx_customers_risk_score ON customers(risk_score);
CREATE INDEX idx_customers_segment ON customers(customer_segment);
CREATE INDEX idx_customers_active_balance ON customers(is_active_member, balance);

-- Table for tracking retention campaigns and interventions
CREATE TABLE retention_actions (
    action_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    action_type TEXT NOT NULL,
    offered_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'Pending',
    notes TEXT,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Executive View 1: Geography & Status Summary View
CREATE VIEW view_churn_summary AS
SELECT 
    geography,
    gender,
    COUNT(customer_id) AS total_customers,
    SUM(exited) AS churned_customers,
    ROUND(AVG(exited) * 100.0, 2) AS churn_rate_pct,
    ROUND(AVG(credit_score), 1) AS avg_credit_score,
    ROUND(AVG(age), 1) AS avg_age,
    ROUND(AVG(balance), 2) AS avg_balance,
    ROUND(SUM(CASE WHEN exited = 1 THEN balance ELSE 0 END), 2) AS capital_lost
FROM customers
GROUP BY geography, gender;

-- Executive View 2: High Value At-Risk Customers View
CREATE VIEW view_high_risk_high_value AS
SELECT 
    customer_id,
    surname,
    geography,
    gender,
    age,
    balance,
    num_of_products,
    is_active_member,
    risk_score,
    customer_segment
FROM customers
WHERE balance >= 100000.0 AND risk_score >= 0.60 AND exited = 0
ORDER BY balance DESC;
